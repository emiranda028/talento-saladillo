export default function Empresas() {
  return (
    <div className="card">
      <h1 className="text-2xl font-semibold mb-2">Empresas</h1>
      <p className="mb-4">Próximamente: creación de vacantes, shortlist sugerido y entrevistas por Zoom.</p>
      <p>Contactanos para activar tu cuenta empresa.</p>
    </div>
  );
}
