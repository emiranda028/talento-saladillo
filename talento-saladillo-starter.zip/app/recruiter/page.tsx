export default function Recruiter() {
  return (
    <div className="card">
      <h1 className="text-2xl font-semibold mb-2">Panel Recruiter</h1>
      <p className="mb-4">Este panel mostrará el pipeline (Aplicados → Pre‑selección → Entrevista → Oferta → Contratado).</p>
      <ul className="list-disc pl-5">
        <li>Lista de vacantes abiertas</li>
        <li>Top candidatos sugeridos (matching básico)</li>
        <li>Agenda de entrevistas (Zoom)</li>
      </ul>
    </div>
  );
}
