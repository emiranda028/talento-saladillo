export default function Home() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <section className="card">
        <h1 className="text-2xl font-semibold mb-2">Trabajo cerca, talento local</h1>
        <p className="mb-4">Cargá tu CV, encontrá oportunidades en Saladillo y alrededores.</p>
        <a href="/postulantes" className="btn btn-primary">Crear mi CV</a>
      </section>
      <section className="card">
        <h2 className="text-xl font-semibold mb-2">¿Sos empresa?</h2>
        <p className="mb-4">Publicá vacantes y recibí perfiles preseleccionados por nuestra Recruiter.</p>
        <a href="/empresas" className="btn btn-outline">Publicar vacante</a>
      </section>
    </div>
  );
}
