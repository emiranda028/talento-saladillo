import fs from 'fs';
import path from 'path';
import { PrismaClient } from '@prisma/client';
import csv from 'csv-parse/sync';

const prisma = new PrismaClient();

async function run() {
  const jobsCsv = fs.readFileSync(path.join(process.cwd(), 'seed', 'talento_saladillo_jobs_demo.csv'), 'utf-8');
  const candsCsv = fs.readFileSync(path.join(process.cwd(), 'seed', 'talento_saladillo_candidates_demo.csv'), 'utf-8');
  const jobs = csv.parse(jobsCsv, { columns: true, skip_empty_lines: true });
  const cands = csv.parse(candsCsv, { columns: true, skip_empty_lines: true });

  // Minimal skills map
  const allSkills = new Set();
  jobs.forEach(j => j.skills_required.split(';').map(s => s.trim()).forEach(s => allSkills.add(s)));
  cands.forEach(c => c.skills.split(';').map(s => s.trim()).forEach(s => allSkills.add(s)));
  for (const name of allSkills) {
    await prisma.skill.upsert({ where: { name }, update: {}, create: { name } });
  }

  // Create one employer admin
  const employer = await prisma.user.upsert({
    where: { email: 'empresa@talentosaladillo.com' },
    update: {},
    create: { email: 'empresa@talentosaladillo.com', name: 'Empresa Demo', role: 'employer' }
  });
  await prisma.employer.upsert({
    where: { userId: employer.id },
    update: {},
    create: { userId: employer.id, orgName: 'Comercio Demo Saladillo', location: 'Saladillo', verified: true }
  });

  // Seed jobs
  for (const j of jobs) {
    const job = await prisma.job.create({
      data: {
        employerId: employer.id,
        title: j.title,
        description: j.skills_required,
        modality: j.modality,
        schedule: j.schedule,
        seniority: j.seniority,
        salaryMin: parseInt(j.salary_min_ars || '0') || null,
        salaryMax: parseInt(j.salary_max_ars || '0') || null,
        location: j.location,
        status: 'open'
      }
    });
    const reqs = j.skills_required.split(';').map(s => s.trim());
    for (const r of reqs) {
      const skill = await prisma.skill.findUnique({ where: { name: r }});
      if (skill) {
        await prisma.jobRequirement.create({
          data: { jobId: job.id, skillId: skill.id, requiredLevel: 3, mandatory: (j.mandatory_skills || '').includes(r) }
        });
      }
    }
  }

  // Seed candidates
  for (const c of cands) {
    const user = await prisma.user.create({
      data: { email: `${c.candidate_id.toLowerCase()}@demo.local`, name: c.name, role: 'candidate' }
    });
    await prisma.candidate.create({
      data: {
        userId: user.id,
        location: c.location,
        availability: c.availability,
        about: `Perfil ${c.domain} con ${c.years_experience} años.`,
      }
    });
    const skills = c.skills.split(';').map(s => s.trim());
    for (const s of skills) {
      const skill = await prisma.skill.findUnique({ where: { name: s }});
      if (skill) {
        await prisma.candidateSkill.create({
          data: { candidateId: user.id, skillId: skill.id, level: 3, years: c.years_experience ? parseInt(c.years_experience) : 0 }
        });
      }
    }
  }
  console.log('Seed completo ✅');
}

run().finally(async () => await prisma.$disconnect());
