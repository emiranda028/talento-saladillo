export default function Postulantes() {
  return (
    <div className="card">
      <h1 className="text-2xl font-semibold mb-2">Postulantes</h1>
      <p className="mb-4">Próximamente: editor de CV, subida de PDF, video de presentación y postulación a avisos.</p>
      <p>Mientras tanto, el admin puede precargar perfiles vía seed.</p>
    </div>
  );
}
